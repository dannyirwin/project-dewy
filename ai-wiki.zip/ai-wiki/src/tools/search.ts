import { supabase } from "../db.js";
import { embed } from "../embeddings/index.js";

export type SearchFilters = {
  metadata?: Record<string, unknown>;
  tags?: string[];
};

export type SearchHit = {
  chunk_id: string;
  document_id: string;
  document_title: string;
  document_slug: string;
  heading_path: string | null;
  content: string;
  metadata: Record<string, unknown>;
  tags: string[];
  score: number;
};

export async function searchKb(
  query: string,
  filters: SearchFilters = {},
  limit = 10,
): Promise<SearchHit[]> {
  const embedding = await embed(query);
  const { data, error } = await supabase.rpc("search_chunks", {
    query_text: query,
    query_embedding: embedding,
    match_count: limit,
    filter_metadata: filters.metadata ?? {},
    filter_tags: filters.tags && filters.tags.length > 0 ? filters.tags : null,
  });
  if (error) throw new Error(`search_chunks failed: ${error.message}`);
  return (data ?? []) as SearchHit[];
}

export async function listTags(): Promise<{ tag: string; count: number }[]> {
  const { data, error } = await supabase.from("documents").select("tags");
  if (error) throw error;
  const counts = new Map<string, number>();
  for (const row of data ?? []) {
    for (const tag of (row.tags ?? []) as string[]) {
      counts.set(tag, (counts.get(tag) ?? 0) + 1);
    }
  }
  return [...counts.entries()]
    .map(([tag, count]) => ({ tag, count }))
    .sort((a, b) => b.count - a.count);
}

export async function listDocuments(opts: {
  filters?: SearchFilters;
  limit?: number;
} = {}) {
  let q = supabase
    .from("documents")
    .select("slug, title, tags, metadata, updated_at")
    .order("updated_at", { ascending: false })
    .limit(opts.limit ?? 50);

  if (opts.filters?.metadata && Object.keys(opts.filters.metadata).length > 0) {
    q = q.contains("metadata", opts.filters.metadata);
  }
  if (opts.filters?.tags && opts.filters.tags.length > 0) {
    q = q.overlaps("tags", opts.filters.tags);
  }
  const { data, error } = await q;
  if (error) throw error;
  return data ?? [];
}
