import { supabase } from "../db.js";

export type RelationKind =
  | "references"
  | "supersedes"
  | "derived-from"
  | "mentions-person"
  | "about-project"
  | string; // open vocabulary; agents may introduce new kinds

export async function linkDocuments(
  fromId: string,
  toId: string,
  kind: RelationKind,
  metadata: Record<string, unknown> = {},
) {
  const { data, error } = await supabase
    .from("relations")
    .upsert(
      { from_id: fromId, to_id: toId, kind, metadata },
      { onConflict: "from_id,to_id,kind" },
    )
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function unlinkDocuments(
  fromId: string,
  toId: string,
  kind: RelationKind,
) {
  const { error } = await supabase
    .from("relations")
    .delete()
    .eq("from_id", fromId)
    .eq("to_id", toId)
    .eq("kind", kind);
  if (error) throw error;
}

export async function relationsFor(
  documentId: string,
  direction: "out" | "in" | "both" = "both",
) {
  if (direction === "out") {
    const { data, error } = await supabase
      .from("relations")
      .select("*")
      .eq("from_id", documentId);
    if (error) throw error;
    return data ?? [];
  }
  if (direction === "in") {
    const { data, error } = await supabase
      .from("relations")
      .select("*")
      .eq("to_id", documentId);
    if (error) throw error;
    return data ?? [];
  }
  const [out, inn] = await Promise.all([
    relationsFor(documentId, "out"),
    relationsFor(documentId, "in"),
  ]);
  return [...out, ...inn];
}
