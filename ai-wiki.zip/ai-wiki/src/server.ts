import "dotenv/config";
import { serve, type HttpBindings } from "@hono/node-server";
import { Hono } from "hono";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";
import { searchKb, listTags, listDocuments } from "./tools/search.js";
import { getDocument } from "./tools/documents.js";
import { enqueue } from "./jobs/enqueue.js";

// ---------------------------------------------------------------
// MCP server factory - read-only tools by default.
// Write operations go through POST /tasks/* (queued) so they're
// auditable and retried, and so we don't expose write-capable
// tools over an unauthenticated MCP endpoint.
// ---------------------------------------------------------------
function createMcpServer(): McpServer {
  const server = new McpServer({ name: "ai-wiki", version: "0.1.0" });

  server.tool(
    "search_kb",
    "Hybrid keyword + semantic search.",
    {
      query: z.string().min(1),
      filters: z
        .object({
          metadata: z.record(z.any()).optional(),
          tags: z.array(z.string()).optional(),
        })
        .optional(),
      limit: z.number().int().min(1).max(50).default(10),
    },
    async ({ query, filters, limit }) => {
      const hits = await searchKb(query, filters ?? {}, limit);
      return { content: [{ type: "text", text: JSON.stringify(hits, null, 2) }] };
    },
  );

  server.tool(
    "get_document",
    "Full markdown body and metadata of a document by slug or UUID.",
    { identifier: z.string() },
    async ({ identifier }) => {
      const doc = await getDocument(identifier);
      if (!doc) {
        return {
          content: [{ type: "text", text: `No document found: ${identifier}` }],
          isError: true,
        };
      }
      const header = [
        `# ${doc.title}`,
        `slug: ${doc.slug}`,
        `tags: ${(doc.tags ?? []).join(", ") || "(none)"}`,
        `metadata: ${JSON.stringify(doc.metadata ?? {})}`,
      ].join("\n");
      return { content: [{ type: "text", text: `${header}\n\n---\n\n${doc.body}` }] };
    },
  );

  server.tool(
    "list_tags",
    "List every tag with document counts.",
    {},
    async () => ({ content: [{ type: "text", text: JSON.stringify(await listTags(), null, 2) }] }),
  );

  server.tool(
    "list_documents",
    "List documents, most recent first.",
    {
      filters: z
        .object({
          metadata: z.record(z.any()).optional(),
          tags: z.array(z.string()).optional(),
        })
        .optional(),
      limit: z.number().int().min(1).max(200).default(50),
    },
    async ({ filters, limit }) => ({
      content: [
        { type: "text", text: JSON.stringify(await listDocuments({ filters, limit }), null, 2) },
      ],
    }),
  );

  return server;
}

// ---------------------------------------------------------------
// Hono app
// ---------------------------------------------------------------
const app = new Hono<{ Bindings: HttpBindings }>();

app.get("/health", (c) => c.json({ ok: true, name: "ai-wiki" }));

// ---- MCP (stateless Streamable HTTP) ----
app.post("/mcp", async (c) => {
  const server = createMcpServer();
  const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
  c.env.outgoing.on("close", () => {
    transport.close();
    server.close();
  });
  try {
    await server.connect(transport);
    const body = await c.req.json();
    await transport.handleRequest(c.env.incoming, c.env.outgoing, body);
    return c.body(null);
  } catch (err) {
    console.error("MCP error:", err);
    if (!c.env.outgoing.headersSent) {
      return c.json(
        { jsonrpc: "2.0", error: { code: -32603, message: "Internal error" }, id: null },
        500,
      );
    }
    return c.body(null);
  }
});

const methodNotAllowed = (c: any) =>
  c.json(
    {
      jsonrpc: "2.0",
      error: { code: -32000, message: "Method not allowed in stateless mode" },
      id: null,
    },
    405,
  );
app.get("/mcp", methodNotAllowed);
app.delete("/mcp", methodNotAllowed);

// ---- Task submission ----
// POST /tasks/distill  -> enqueue a distill job
app.post("/tasks/distill", async (c) => {
  const body = await c.req.json();
  const parsed = z
    .object({
      content: z.string().min(1),
      source_type: z.enum(["transcript", "notes", "summary", "document"]),
      source: z.string().optional(),
      metadata: z.record(z.any()).optional(),
      idempotency_key: z.string().optional(),
    })
    .safeParse(body);
  if (!parsed.success) {
    return c.json({ error: "validation_error", details: parsed.error.flatten() }, 400);
  }
  const job = await enqueue({
    kind: "distill",
    payload: parsed.data,
    idempotencyKey: parsed.data.idempotency_key,
  });
  return c.json(job, 202);
});

// POST /tasks/enqueue  -> generic enqueue for any registered handler
app.post("/tasks/enqueue", async (c) => {
  const body = await c.req.json();
  const parsed = z
    .object({
      kind: z.string(),
      payload: z.record(z.any()).default({}),
      idempotency_key: z.string().optional(),
      scheduled_for: z.string().datetime().optional(),
    })
    .safeParse(body);
  if (!parsed.success) {
    return c.json({ error: "validation_error", details: parsed.error.flatten() }, 400);
  }
  const job = await enqueue({
    kind: parsed.data.kind,
    payload: parsed.data.payload,
    idempotencyKey: parsed.data.idempotency_key,
    scheduledFor: parsed.data.scheduled_for ? new Date(parsed.data.scheduled_for) : undefined,
  });
  return c.json(job, 202);
});

// ---------------------------------------------------------------
// Local entrypoint
// ---------------------------------------------------------------
const isMain = import.meta.url === `file://${process.argv[1]}`;
if (isMain) {
  const port = Number(process.env.PORT ?? 3000);
  serve({ fetch: app.fetch, port }, (info) => {
    console.log(`ai-wiki on http://localhost:${info.port}`);
    console.log(`  POST /mcp             MCP endpoint`);
    console.log(`  POST /tasks/distill   submit content for distillation`);
    console.log(`  POST /tasks/enqueue   enqueue any registered job kind`);
    console.log(`  GET  /health`);
  });
}

export { app };
