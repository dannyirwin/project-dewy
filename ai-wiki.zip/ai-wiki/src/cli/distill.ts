import "dotenv/config";
import fs from "node:fs/promises";
import { distill } from "../agents/distill.js";

// Usage:
//   npm run distill -- <path> [transcript|notes|summary|document]
//
// Runs the distill agent inline (no queue). Useful for testing agent
// prompts and seeing token usage without spinning up the worker.

async function main() {
  const [path, kind] = process.argv.slice(2);
  if (!path) {
    console.error("Usage: npm run distill -- <path> [source_type]");
    process.exit(1);
  }
  const content = await fs.readFile(path, "utf8");
  const sourceType = (kind ?? "notes") as
    | "transcript"
    | "notes"
    | "summary"
    | "document";

  console.log(`Distilling ${path} (${sourceType}, ${content.length} chars)...`);
  const t0 = Date.now();
  const result = await distill({
    content,
    source_type: sourceType,
    source: path,
  });
  const ms = Date.now() - t0;

  console.log("\n--- result ---");
  console.log(JSON.stringify(result, null, 2));
  console.log(`\nTook ${ms}ms`);
  console.log(
    `Tokens: ${result.usage.promptTokens} in / ${result.usage.completionTokens} out`,
  );
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
