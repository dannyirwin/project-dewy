import "dotenv/config";
import { runWorker } from "./jobs/runner.js";

const ac = new AbortController();
process.on("SIGINT", () => ac.abort());
process.on("SIGTERM", () => ac.abort());

runWorker({ signal: ac.signal }).catch((err) => {
  console.error("worker fatal:", err);
  process.exit(1);
});
