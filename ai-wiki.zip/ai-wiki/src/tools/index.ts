import { tool } from "ai";
import { z } from "zod";
import { searchKb, listTags, listDocuments } from "./search.js";
import {
  getDocument,
  upsertDocument,
  updateDocument,
} from "./documents.js";
import { linkDocuments, relationsFor } from "./relations.js";

// ---------------------------------------------------------------
// AI SDK tools.
//
// Each tool wraps a plain function. The agent invokes tools via
// the AI SDK's tool-call loop; humans / ingest scripts invoke the
// underlying functions directly. Same logic either way.
// ---------------------------------------------------------------

export const readTools = {
  search_kb: tool({
    description:
      "Hybrid keyword + semantic search. Use filters.metadata for structured " +
      "fields (e.g. { state: 'CA' }), filters.tags for tag filtering.",
    parameters: z.object({
      query: z.string().min(1),
      filters: z
        .object({
          metadata: z.record(z.any()).optional(),
          tags: z.array(z.string()).optional(),
        })
        .optional(),
      limit: z.number().int().min(1).max(50).default(10),
    }),
    execute: async ({ query, filters, limit }) =>
      searchKb(query, filters ?? {}, limit),
  }),

  get_document: tool({
    description: "Fetch the full body and metadata of a document by slug or UUID.",
    parameters: z.object({ identifier: z.string() }),
    execute: async ({ identifier }) => getDocument(identifier),
  }),

  list_tags: tool({
    description: "List every tag in use with document counts.",
    parameters: z.object({}),
    execute: async () => listTags(),
  }),

  list_documents: tool({
    description:
      "List documents, most-recently-updated first. Same metadata/tag filters as search_kb.",
    parameters: z.object({
      filters: z
        .object({
          metadata: z.record(z.any()).optional(),
          tags: z.array(z.string()).optional(),
        })
        .optional(),
      limit: z.number().int().min(1).max(200).default(50),
    }),
    execute: async ({ filters, limit }) => listDocuments({ filters, limit }),
  }),

  relations_for: tool({
    description: "List relations (typed edges) for a document.",
    parameters: z.object({
      document_id: z.string().uuid(),
      direction: z.enum(["out", "in", "both"]).default("both"),
    }),
    execute: async ({ document_id, direction }) =>
      relationsFor(document_id, direction),
  }),
};

export const writeTools = {
  create_document: tool({
    description:
      "Create a new document. Slug auto-generated from title if not provided. " +
      "Use this when distilled content represents a topic that doesn't yet exist.",
    parameters: z.object({
      title: z.string(),
      body: z.string(),
      slug: z.string().optional(),
      tags: z.array(z.string()).optional(),
      metadata: z.record(z.any()).optional(),
    }),
    execute: async (input) =>
      upsertDocument({ ...input, source: "agent:create_document" }),
  }),

  update_document: tool({
    description:
      "Patch an existing document. Only provided fields are written. " +
      "Body is re-chunked if changed; unchanged chunks skip re-embedding.",
    parameters: z.object({
      id: z.string().uuid(),
      title: z.string().optional(),
      body: z.string().optional(),
      tags: z.array(z.string()).optional(),
      metadata: z.record(z.any()).optional(),
    }),
    execute: async ({ id, ...patch }) => updateDocument(id, patch),
  }),

  link_documents: tool({
    description:
      "Create a typed relation between two documents. Examples of kind: " +
      "'references', 'supersedes', 'derived-from', 'mentions-person', 'about-project'.",
    parameters: z.object({
      from_id: z.string().uuid(),
      to_id: z.string().uuid(),
      kind: z.string(),
      metadata: z.record(z.any()).optional(),
    }),
    execute: async ({ from_id, to_id, kind, metadata }) =>
      linkDocuments(from_id, to_id, kind, metadata),
  }),
};

export const allTools = { ...readTools, ...writeTools };
