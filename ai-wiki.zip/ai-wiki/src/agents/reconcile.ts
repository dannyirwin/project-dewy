import { generateObject } from "ai";
import { z } from "zod";
import { model } from "../llm/index.js";
import { searchKb } from "../tools/search.js";
import type { Entity } from "./extract-entities.js";

// ---------------------------------------------------------------
// For each entity, decide: does it correspond to an existing doc,
// is it merely related to one, or should it be a new doc?
//
// Token-conscious pattern:
//   1. DETERMINISTIC: embedding search finds top 5 candidates.
//   2. LLM: judge only those candidates, with short context.
//
// If we asked the LLM to remember all docs, we'd be either
// paying for a huge context every call, or hoping it remembers
// what it doesn't. Pre-filtering with retrieval is free and
// dramatically narrows the choice.
// ---------------------------------------------------------------

const Schema = z.object({
  decision: z.enum(["existing_match", "related_to", "create_new"]),
  target_slug: z
    .string()
    .nullable()
    .describe("Slug of the matched/related doc, or null when create_new"),
  relation_kind: z
    .string()
    .nullable()
    .describe(
      "If related_to, the relation kind. E.g. 'mentions-person', 'about-project'.",
    ),
  rationale: z.string().describe("One short sentence."),
});
export type ReconcileResult = z.infer<typeof Schema>;

export async function reconcile(entity: Entity): Promise<{
  entity: Entity;
  result: ReconcileResult;
  usage: { promptTokens: number; completionTokens: number };
}> {
  // 1. Cheap retrieval. We pass the entity name + context as the query.
  const candidates = await searchKb(`${entity.name} ${entity.context}`, {}, 5);

  // Short-circuit when there are no candidates — no need to spend tokens.
  if (candidates.length === 0) {
    return {
      entity,
      result: {
        decision: "create_new",
        target_slug: null,
        relation_kind: null,
        rationale: "No candidate docs found in KB.",
      },
      usage: { promptTokens: 0, completionTokens: 0 },
    };
  }

  // Compact candidate summary — small, focused context.
  const candidateBlock = candidates
    .map(
      (c, i) =>
        `[${i + 1}] slug=${c.document_slug} title="${c.document_title}" ${
          c.heading_path ? `§ ${c.heading_path}` : ""
        }\n    ${c.content.replace(/\s+/g, " ").slice(0, 200)}`,
    )
    .join("\n");

  const { object, usage } = await generateObject({
    model: model(),
    schema: Schema,
    system:
      "Decide whether an extracted entity already has a knowledge-base document. " +
      "Use 'existing_match' only when the candidate IS this entity. " +
      "Use 'related_to' when the candidate is about this entity but doesn't own it (e.g. a meeting that mentions a person). " +
      "Otherwise 'create_new'.",
    prompt:
      `ENTITY:\n  name: ${entity.name}\n  type: ${entity.type}\n  context: ${entity.context}\n\n` +
      `CANDIDATES (top ${candidates.length} by hybrid search):\n${candidateBlock}\n\n` +
      `Decide.`,
  });

  return {
    entity,
    result: object,
    usage: {
      promptTokens: usage?.promptTokens ?? 0,
      completionTokens: usage?.completionTokens ?? 0,
    },
  };
}
