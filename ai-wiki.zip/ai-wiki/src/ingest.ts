import "dotenv/config";
import fs from "node:fs/promises";
import path from "node:path";
import matter from "gray-matter";
import { upsertDocument } from "./tools/documents.js";

async function ingestFile(filePath: string) {
  const raw = await fs.readFile(filePath, "utf8");
  const { data: fm, content: body } = matter(raw);

  const slug = (fm.slug as string) ?? path.basename(filePath, path.extname(filePath));
  const title = (fm.title as string) ?? slug;
  const tags = (fm.tags as string[]) ?? [];

  const reserved = new Set(["slug", "title", "tags"]);
  const metadata: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(fm)) {
    if (!reserved.has(k)) metadata[k] = v;
  }

  const doc = await upsertDocument({
    slug,
    title,
    body,
    tags,
    metadata,
    source: filePath,
  });
  console.log(`✓ ${slug}  →  ${doc.id}`);
}

async function walk(dir: string): Promise<string[]> {
  const out: string[] = [];
  const entries = await fs.readdir(dir, { withFileTypes: true });
  for (const e of entries) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...(await walk(p)));
    else if (e.name.endsWith(".md")) out.push(p);
  }
  return out;
}

async function main() {
  const dir = process.argv[2] ?? "./content";
  const files = await walk(dir);
  if (files.length === 0) {
    console.log(`No .md files under ${dir}`);
    return;
  }
  for (const f of files) {
    try {
      await ingestFile(f);
    } catch (err) {
      console.error(`✗ ${f}:`, err);
    }
  }
}

main();
