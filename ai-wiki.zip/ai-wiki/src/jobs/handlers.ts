import { supabase } from "../db.js";
import { distill, type DistillInput } from "../agents/distill.js";
import { embed } from "../embeddings/index.js";
import { rebuildChunks, getDocument } from "../tools/documents.js";

// ---------------------------------------------------------------
// Each handler takes (payload, jobId) and either resolves or throws.
// Throws are caught by the runner and recorded for retry.
// ---------------------------------------------------------------

export type JobHandler = (
  payload: any,
  jobId: string,
) => Promise<Record<string, unknown> | void>;

export const handlers: Record<string, JobHandler> = {
  // -----------------------------------------------------------
  // distill: turn raw content into a structured wiki doc.
  // Payload: DistillInput
  // -----------------------------------------------------------
  distill: async (payload: DistillInput, jobId) => {
    return distill({ ...payload, job_id: jobId });
  },

  // -----------------------------------------------------------
  // reembed_stale: re-embed chunks whose embeddings are null
  // (e.g. after switching embedding provider or a partial ingest).
  // Used by the nightly scheduler.
  // -----------------------------------------------------------
  reembed_stale: async (payload: { limit?: number }) => {
    const limit = payload?.limit ?? 200;
    const { data: rows, error } = await supabase
      .from("chunks")
      .select("id, content, document_id, heading_path")
      .is("embedding", null)
      .limit(limit);
    if (error) throw error;
    if (!rows || rows.length === 0) return { processed: 0 };

    // Fetch the parent doc titles for richer embedding input.
    const docIds = Array.from(new Set(rows.map((r) => r.document_id)));
    const { data: docs } = await supabase
      .from("documents")
      .select("id, title")
      .in("id", docIds);
    const titleById = new Map<string, string>(
      (docs ?? []).map((d) => [d.id, d.title]),
    );

    for (const row of rows) {
      const title = titleById.get(row.document_id) ?? "";
      const input = [
        `Document: ${title}`,
        row.heading_path && `Section: ${row.heading_path}`,
        "",
        row.content,
      ]
        .filter(Boolean)
        .join("\n");
      const vec = await embed(input);
      await supabase.from("chunks").update({ embedding: vec }).eq("id", row.id);
    }
    return { processed: rows.length };
  },

  // -----------------------------------------------------------
  // refresh_document_chunks: re-chunk a specific document.
  // Useful when chunking strategy changes.
  // -----------------------------------------------------------
  refresh_document_chunks: async (payload: { document_id: string }) => {
    const doc = await getDocument(payload.document_id);
    if (!doc) throw new Error(`No document ${payload.document_id}`);
    return rebuildChunks(doc.id, doc.title, doc.body);
  },
};
