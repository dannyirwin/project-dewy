---
slug: solar-itc-federal
title: Federal Solar Investment Tax Credit
tags: [solar, federal, tax-credit, incentive]
jurisdiction: federal
country: US
effective_date: 2022-08-16
---

# Federal Solar Investment Tax Credit (ITC)

The federal Investment Tax Credit lets homeowners and businesses deduct a
percentage of the cost of installing a solar energy system from their federal
income taxes.

## Current Rate

As of 2026, the residential ITC is 30% for systems placed in service through
2032. It steps down to 26% in 2033 and 22% in 2034 under current law.

## Eligibility

- The solar PV system must be located at a residence in the United States.
- Systems must be new or being used for the first time.
- The taxpayer must own the system outright (cash purchase or loan).
  Leased systems and PPAs do not qualify for the residential credit.

## How to Claim

File IRS Form 5695 with your federal tax return for the year the system was
placed in service. Unused credit may carry forward to future tax years.
