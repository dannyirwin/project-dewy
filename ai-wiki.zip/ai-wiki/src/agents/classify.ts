import { generateObject } from "ai";
import { z } from "zod";
import { model } from "../llm/index.js";

const Schema = z.object({
  title: z.string().describe("Concise, specific title for the distilled document"),
  summary_line: z.string().describe("One-sentence summary, no preamble"),
  tags: z
    .array(z.string())
    .max(8)
    .describe("Lowercase, hyphenated tags. Prefer reusing the existing tag vocabulary if provided."),
  doc_type: z
    .enum(["meeting-notes", "decision-record", "summary", "reference", "transcript-distill"])
    .describe("What kind of document this should become"),
});
export type Classification = z.infer<typeof Schema>;

export async function classify(
  content: string,
  sourceType: string,
  knownTags: string[] = [],
): Promise<{ classification: Classification; usage: { promptTokens: number; completionTokens: number } }> {
  const tagHint = knownTags.length > 0
    ? `Existing tag vocabulary (prefer these): ${knownTags.slice(0, 50).join(", ")}`
    : "";

  const { object, usage } = await generateObject({
    model: model(),
    schema: Schema,
    system:
      "You classify and title content for a knowledge base. Be specific in titles — " +
      "'Q3 Pricing Review' is better than 'Meeting Notes'. " +
      tagHint,
    prompt: `SOURCE TYPE: ${sourceType}\n\nCONTENT:\n\n${content}\n\nClassify and title this.`,
  });
  return {
    classification: object,
    usage: {
      promptTokens: usage?.promptTokens ?? 0,
      completionTokens: usage?.completionTokens ?? 0,
    },
  };
}
