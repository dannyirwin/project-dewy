import { supabase } from "../db.js";

export type EnqueueOpts = {
  kind: string;
  payload: Record<string, unknown>;
  scheduledFor?: Date;
  idempotencyKey?: string;
  maxAttempts?: number;
};

export async function enqueue(opts: EnqueueOpts) {
  const row = {
    kind: opts.kind,
    payload: opts.payload,
    scheduled_for: (opts.scheduledFor ?? new Date()).toISOString(),
    idempotency_key: opts.idempotencyKey ?? null,
    max_attempts: opts.maxAttempts ?? 3,
  };

  // Use ON CONFLICT (idempotency_key) DO NOTHING-style semantics by
  // letting the unique index reject duplicates.
  const { data, error } = await supabase
    .from("jobs")
    .insert(row)
    .select("id, kind, scheduled_for, status")
    .single();

  if (error) {
    // Postgres unique violation on idempotency_key
    if ((error as any).code === "23505" && opts.idempotencyKey) {
      const { data: existing } = await supabase
        .from("jobs")
        .select("id, kind, scheduled_for, status")
        .eq("idempotency_key", opts.idempotencyKey)
        .single();
      return { ...existing!, deduplicated: true as const };
    }
    throw error;
  }
  return { ...data, deduplicated: false as const };
}
