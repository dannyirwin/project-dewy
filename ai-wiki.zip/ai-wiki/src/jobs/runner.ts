import { supabase } from "../db.js";
import { handlers } from "./handlers.js";

const POLL_MS = 2000;

export async function runWorker(opts: { signal?: AbortSignal } = {}) {
  console.log("worker: started, polling every", POLL_MS, "ms");

  while (!opts.signal?.aborted) {
    const job = await claimNext();
    if (!job) {
      await sleep(POLL_MS, opts.signal);
      continue;
    }
    await runJob(job);
  }
  console.log("worker: stopping");
}

async function claimNext() {
  // Use the SQL function for atomic SELECT-FOR-UPDATE-SKIP-LOCKED.
  const { data, error } = await supabase.rpc("claim_next_job");
  if (error) {
    console.error("worker: claim_next_job failed:", error);
    return null;
  }
  // RPC returning a single ROW gives us an array with 0 or 1 elements.
  const rows = Array.isArray(data) ? data : data ? [data] : [];
  return rows[0] ?? null;
}

async function runJob(job: any) {
  const handler = handlers[job.kind];
  console.log(`worker: claimed job ${job.id} (kind=${job.kind}, attempt=${job.attempts})`);

  if (!handler) {
    await markFailed(job.id, `No handler registered for kind '${job.kind}'`, /* fatal */ true);
    return;
  }

  try {
    const result = await handler(job.payload, job.id);
    await supabase
      .from("jobs")
      .update({
        status: "complete",
        completed_at: new Date().toISOString(),
        last_error: null,
        payload: { ...job.payload, _result: result ?? null },
      })
      .eq("id", job.id);
    console.log(`worker: ✓ ${job.id}`);
  } catch (err: any) {
    const msg = err?.stack ?? err?.message ?? String(err);
    console.error(`worker: ✗ ${job.id}:`, msg);
    const fatal = job.attempts >= job.max_attempts;
    await markFailed(job.id, msg, fatal);
  }
}

async function markFailed(jobId: string, error: string, fatal: boolean) {
  if (fatal) {
    await supabase
      .from("jobs")
      .update({
        status: "failed",
        completed_at: new Date().toISOString(),
        last_error: error,
      })
      .eq("id", jobId);
  } else {
    // Re-queue with backoff (exponential, capped). Status back to 'queued'.
    const { data: job } = await supabase.from("jobs").select("attempts").eq("id", jobId).single();
    const attempts = job?.attempts ?? 1;
    const delaySec = Math.min(60 * 5, 2 ** attempts);
    const nextAt = new Date(Date.now() + delaySec * 1000).toISOString();
    await supabase
      .from("jobs")
      .update({
        status: "queued",
        scheduled_for: nextAt,
        last_error: error,
      })
      .eq("id", jobId);
  }
}

function sleep(ms: number, signal?: AbortSignal) {
  return new Promise<void>((resolve) => {
    const t = setTimeout(resolve, ms);
    signal?.addEventListener("abort", () => {
      clearTimeout(t);
      resolve();
    });
  });
}
