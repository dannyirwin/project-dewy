---
slug: solar-ca-nem3
title: California Net Energy Metering 3.0 (NEM 3.0)
tags: [solar, california, net-metering, interconnection]
jurisdiction: state
state: CA
country: US
effective_date: 2023-04-15
---

# California Net Energy Metering 3.0

NEM 3.0, officially the Net Billing Tariff, governs how rooftop solar customers
of California's three major investor-owned utilities (PG&E, SCE, SDG&E) are
compensated for excess generation exported to the grid.

## Export Compensation

Exports are valued at an Avoided Cost Calculator rate that varies by hour and
month, rather than the retail-rate credit that prevailed under NEM 2.0. Average
export values are roughly 75% lower than under NEM 2.0.

## Battery Storage

Because export rates are low during midday and high in the evening,
pairing solar with battery storage is generally required to achieve attractive
payback periods under NEM 3.0.

## Grandfathering

Customers who submitted a complete interconnection application before April 15,
2023 retain NEM 2.0 terms for 20 years from their permission-to-operate date.
