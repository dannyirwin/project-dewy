import "dotenv/config";
import cron from "node-cron";
import { enqueue } from "./jobs/enqueue.js";

// ---------------------------------------------------------------
// Scheduler: a long-running process that enqueues jobs on a cron.
// Keep this thin — actual work lives in handlers, not here.
//
// For production:
//   * Fly: run scheduler.ts in a separate process / machine.
//   * Lambda: use EventBridge Scheduler to invoke a Lambda that
//     enqueues. You don't need this file at all in that setup.
//   * Supabase: pg_cron can call a SQL function that inserts into
//     jobs directly. Also a fine option, eliminates this process.
// ---------------------------------------------------------------

// Every 15 minutes: re-embed any chunks left with NULL embeddings.
cron.schedule("*/15 * * * *", async () => {
  try {
    const job = await enqueue({
      kind: "reembed_stale",
      payload: { limit: 200 },
      idempotencyKey: `reembed_stale:${minuteBucket(15)}`,
    });
    console.log(`scheduler: queued reembed_stale (${job.deduplicated ? "dedup" : "new"})`);
  } catch (err) {
    console.error("scheduler: enqueue failed:", err);
  }
});

// Example: nightly housekeeping at 03:00 UTC.
// Add more here as needed.
cron.schedule("0 3 * * *", async () => {
  console.log("scheduler: nightly tick");
  // Place for: "fill stub documents", "archive stale drafts", etc.
});

console.log("scheduler: running");

function minuteBucket(intervalMin: number): string {
  const d = new Date();
  const bucket = Math.floor(d.getUTCMinutes() / intervalMin) * intervalMin;
  return `${d.toISOString().slice(0, 13)}:${bucket.toString().padStart(2, "0")}`;
}
