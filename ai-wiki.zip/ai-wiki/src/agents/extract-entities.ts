import { generateObject } from "ai";
import { z } from "zod";
import { model } from "../llm/index.js";

// ---------------------------------------------------------------
// One focused LLM call. Structured output (Zod schema) means we
// don't parse prose — we get typed objects out.
//
// Why split this out from "distill": local 7-13B models can hit a
// single-purpose JSON schema reliably; they fall over on a giant
// agentic prompt that does everything at once.
// ---------------------------------------------------------------

export const EntitySchema = z.object({
  name: z.string().describe("Canonical name of the entity"),
  type: z
    .enum(["person", "project", "decision", "action_item", "topic", "organization"])
    .describe("What kind of entity this is"),
  context: z.string().describe("Short phrase describing the entity in context"),
});
export type Entity = z.infer<typeof EntitySchema>;

const Schema = z.object({
  entities: z.array(EntitySchema),
});

export async function extractEntities(content: string): Promise<{
  entities: Entity[];
  usage: { promptTokens: number; completionTokens: number };
}> {
  const { object, usage } = await generateObject({
    model: model(),
    schema: Schema,
    system:
      "Extract the named entities a knowledge base would want to track. " +
      "Be precise: prefer fewer high-quality entities over many low-confidence ones. " +
      "Skip generic concepts. Names should be the canonical form (e.g. 'Acme Corp', not 'the company').",
    prompt: `CONTENT:\n\n${content}\n\nExtract entities.`,
  });
  return {
    entities: object.entities,
    usage: {
      promptTokens: usage?.promptTokens ?? 0,
      completionTokens: usage?.completionTokens ?? 0,
    },
  };
}
