import "dotenv/config";
import { searchKb } from "./tools/search.js";

async function main() {
  const [query, metadataJson, tagsJson] = process.argv.slice(2);
  if (!query) {
    console.error('Usage: npm run query -- "<query>" [metadataJson] [tagsJson]');
    process.exit(1);
  }
  const metadata = metadataJson ? JSON.parse(metadataJson) : undefined;
  const tags = tagsJson ? JSON.parse(tagsJson) : undefined;

  const hits = await searchKb(query, { metadata, tags }, 10);
  for (const h of hits) {
    console.log(`\n[${h.score.toFixed(4)}] ${h.document_title}  (${h.document_slug})`);
    if (h.heading_path) console.log(`    § ${h.heading_path}`);
    console.log(
      "    " + h.content.replace(/\s+/g, " ").slice(0, 200) +
        (h.content.length > 200 ? "…" : ""),
    );
  }
}

main();
